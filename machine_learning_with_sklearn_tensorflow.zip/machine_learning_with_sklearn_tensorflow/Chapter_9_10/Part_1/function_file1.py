
# creating a function in python 3

def adding_numbers(a,b):
    result1 = a + b
    return result1
